// Basic JavaScript program

console.log("Hello World!"); // prints Hello World!

/* This statement is used to print in console of the browser. 
This program demonstrates basic JavaScript concepts such as 
variables, console.log(), comments and statements. */

console.log("JavaScript program execution completed.");

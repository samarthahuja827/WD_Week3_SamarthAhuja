let name; // declaration
name = "Samarth"; // assignment

const college = "VIPS";

let age = 19;
let isStudent = true;
let result;
let address = null;

console.log("Name:", name);
console.log("College:", college);
console.log("Age:", age);
console.log("Student:", isStudent);
console.log("Result:", result);
console.log("Address:", address);

console.log(typeof name);
console.log(typeof college);
console.log(typeof age);
console.log(typeof isStudent);
console.log(typeof result);
console.log(typeof address);

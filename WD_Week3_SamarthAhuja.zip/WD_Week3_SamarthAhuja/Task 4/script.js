let num = 10;

// if statement
if (num > 0) {
  console.log("The number is positive.");
}

// if-else statement
if (num % 2 == 0) {
  console.log("The number is even.");
} else {
  console.log("The number is odd.");
}

// else if statement
let marks = 75;

if (marks >= 90) {
  console.log("Grade A");
} else if (marks >= 75) {
  console.log("Grade B");
} else if (marks >= 50) {
  console.log("Grade C");
} else {
  console.log("Grade F");
}

// Nested if
let age = 20;

if (age >= 18) {
  if (age <= 25) {
    console.log("Age is eligible for the exam.");
  }
}

// Logical condition
let userAge = 22;
let hasID = true;

if (userAge >= 18 && hasID) {
  console.log("Entry is allowed.");
}

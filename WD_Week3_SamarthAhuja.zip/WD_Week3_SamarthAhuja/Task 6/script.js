// Program 1
// User details

const name = "Rohit";
let age = 28;
let married = true;
console.log("Name:", name);
console.log("Age:", age);
console.log("Married:", married);
console.log("Data type of name:", typeof name);
console.log("Data type of age:", typeof age);
console.log("Data type of married:", typeof married);

// Program 2
// Find the greater of two numbers
let a = 25;
let b = 15;
console.log("a=25 and b=15");

if (a > b) {
  console.log("Greater number:", a);
} else {
  console.log("Greater number:", b);
}

// Program 3
// Calculate the sum of even numbers from 1 to 10
let sum = 0;

for (let i = 1; i <= 10; i++) {
  if (i % 2 == 0) {
    sum += i;
  }
}
console.log("Sum of even numbers from 1 to 10:", sum);

// Program 4
// Voting eligibility

let currentAge = 19;
console.log("current age = 19");
if (currentAge >= 18) {
  console.log("You can vote.");
} else {
  console.log("You cannot vote.");
}

// Program 5
// Check whether a number is positive, negative or zero
let number = -17;
console.log("number = -17");

if (number > 0) {
  console.log("Positive");
} else if (number < 0) {
  console.log("Negative");
} else {
  console.log("Zero");
}

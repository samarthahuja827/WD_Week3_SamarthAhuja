let a = 10;
let b = 5;
console.log("a: ", a);
console.log("b: ", b);

// Arithmetic Operators
console.log("Addition:", a + b);
console.log("Subtraction:", a - b);
console.log("Multiplication:", a * b);
console.log("Division:", a / b);
console.log("Modulus:", a % b);

// Assignment Operators
let x = 10;
console.log("x: ", x);
x += 5;
console.log("After using += 5 ie [x=x+5]:", x);
console.log("now x= ", x);
x -= 3;
console.log("After -= 3 ie [x=x-3]:", x);

// Comparison Operators
console.log("Is a equal to b? ie (a === b):", a === b);
console.log("Is a not equal to b? ie (a != b):", a != b);
console.log("Is a greater than b? ie (a > b):", a > b);
console.log("Is a less than b? ie (a < b):", a < b);

// Logical Operators
console.log(
  "Is a greater than 5 AND b less than 10? ie (a > 5 && b < 10):",
  a > 5 && b < 10,
);
console.log(
  "Is a greater than 15 OR b less than 10? ie (a > 15 || b < 10):",
  a > 15 || b < 10,
);
console.log("Is a NOT greater than b? ie !(a > b):", !(a > b));

let count = 1;
console.log("count:", count);
// Increment Operator
count++;
console.log("After increment count:", count);

console.log("now count=", count);
// Decrement Operator
count--;
console.log("After decrement count:", count);

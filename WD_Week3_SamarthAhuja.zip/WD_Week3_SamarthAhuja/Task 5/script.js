// for loop
// Printing numbers from 1 to 10
console.log("Printing numbers from 1 to 10");
for (let i = 1; i <= 10; i++) {
  console.log(i);
}

// while loop using conditional statement
// Printing even numbers
console.log("Printing even numbers");
let k = 2;
while (k <= 10) {
  if (k % 2 == 0) {
    console.log(k);
  }
  k++;
}

// do....while loop
// Printing odd numbers
console.log("Printing odd numbers");
let j = 1;
do {
  console.log(j);
  j += 2;
} while (j <= 10);

// Multiplication table of 5
console.log("Multiplication table of 5");
let num = 5;
for (let x = 1; x <= 10; x++) {
  console.log(num + " x " + x + " = " + num * x);
}

// Sum of first 10 natural numbers
console.log("Sum of first 10 natural numbers");
let sum = 0;
for (let i = 1; i <= 10; i++) {
  sum += i;
}
console.log("Sum = ", sum);

// printing numbers in reverse order
console.log("printing numbers in reverse order");
for (let i = 10; i >= 1; i--) {
  console.log(i);
}
